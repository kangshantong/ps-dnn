# PS-Lite Documents

PS-Lite is a lightweight implementation of the parameter server.  It provides
asynchronous and zero-copy key-value pair communication between machines.


```eval_rst
.. toctree::
   :numbered:

   overview
   get_started
   how_to
   api
   history
```
